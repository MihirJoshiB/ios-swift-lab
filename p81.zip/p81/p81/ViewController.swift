//
//  ViewController.swift
//  p81
//
//  Created by bmiit on 21/04/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var doubletap: UIButton!
    @IBOutlet var swipview: UIView!
    @IBOutlet var longpress: UIButton!
    @IBOutlet var rotation: UIView!
    
    @IBOutlet var imageview: UIImageView!
    
    @IBOutlet var scaleiamge: UIPinchGestureRecognizer!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let tap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
            tap.numberOfTapsRequired = 2
            doubletap.addGestureRecognizer(tap)
        
        let longp = UILongPressGestureRecognizer(target: self, action: #selector(longpressss))
        longp.minimumPressDuration = 2
        longpress.addGestureRecognizer(longp)
        
        let directions: [UISwipeGestureRecognizer.Direction] = [.right , .left]
        
        for direction in directions {
                let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(swipwView))
                swipview.addGestureRecognizer(swipeGesture)
                swipeGesture.direction = direction
                swipview.isUserInteractionEnabled = true
                swipview.isMultipleTouchEnabled = true
            }
        
       
      
        
        //ROTATE Gesture
          let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(rotatedView))
           rotation.addGestureRecognizer(rotateGesture)
           rotation.isUserInteractionEnabled = true
           rotation.isMultipleTouchEnabled = true
    }

        @objc func doubleTapped() {
            let alertController = UIAlertController(title: "Double Tap", message:
               "Double Gesture Detected", preferredStyle: .alert)
               alertController.addAction(UIAlertAction(title: "OK", style: .default,handler: nil))
            present(alertController, animated: true, completion: nil)
            // do something here

        }
    
    @objc func longpressss(_ sender: UILongPressGestureRecognizer) {
       let alertController = UIAlertController(title: "Long Press", message:
          "Long Press Gesture Detected", preferredStyle: .alert)
          alertController.addAction(UIAlertAction(title: "OK", style: .default,handler: nil))
       present(alertController, animated: true, completion: nil)
    }
    
    @objc func swipwView(_ sender : UISwipeGestureRecognizer){
        UIView.animate(withDuration: 1.0) {
            
            if sender.direction == .right {
           
                self.swipview.frame = CGRect(x: self.view.frame.size.width - self.swipview.frame.size.width, y: self.swipview.frame.origin.y , width: self.swipview.frame.size.width, height: self.swipview.frame.size.height)
            }
            else if sender.direction == .left{
                        self.swipview.frame = CGRect(x: 0, y: self.swipview.frame.origin.y , width: self.swipview.frame.size.width, height: self.swipview.frame.size.height)
            }
            self.swipview.layoutIfNeeded()
            self.swipview.setNeedsDisplay()
        
    }
    }
    
    @objc func rotatedView(_ sender : UIRotationGestureRecognizer){
        var lastRotation = CGFloat()
        self.view.bringSubviewToFront(rotation)
        if(sender.state == UIGestureRecognizer.State.ended){
            lastRotation = 0.0;
        }
        let rotation = 0.0 - (lastRotation - sender.rotation)
       // var point = rotateGesture.location(in: viewRotate)
        let currentTrans = sender.view?.transform
        let newTrans = currentTrans!.rotated(by: rotation)
        sender.view?.transform = newTrans
        lastRotation = sender.rotation
    }
    
    @IBAction func scaleiamge(_ sender: UIPinchGestureRecognizer) {
        imageview.transform = CGAffineTransform(scaleX: sender.scale, y: sender.scale)
    }
}

