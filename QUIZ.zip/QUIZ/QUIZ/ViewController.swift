//
//  ViewController.swift
//  QUIZ
//
//  Created by bmiit on 08/03/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var QuestionLable: UILabel!
    @IBOutlet var AnswerLabel: UILabel!
    
    let question: [String] = [
        "What is 7 + 7?",
        "Captial of india?",
        "Summer Favourite Fruit?"
    ]
    
    
    let answer: [String] = [
        "14",
        "Delhi",
        "Mango"
    ]
    
    var currentindex: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        let question: String = question[currentindex]
        QuestionLable.text = question
    }

    @IBAction func shownextquestion(_ sender: UIButton) {
        
        currentindex += 1
        if currentindex == question.count
        {
            currentindex = 0
        }
        let question: String = question[currentindex]
        QuestionLable.text = question
        AnswerLabel.text = "???"
        
    }
    
    @IBAction func showanswer(_ sender: UIButton) {
        
        let answer: String = answer[currentindex]
        AnswerLabel.text = answer
    }
}

