import UIKit

class notecell: UITableViewCell
{
    @IBOutlet weak var titleLabel : UILabel!
    @IBOutlet weak var descLabel : UILabel!
    
    
    
}
