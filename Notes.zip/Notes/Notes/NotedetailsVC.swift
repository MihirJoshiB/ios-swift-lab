//
//  ViewController.swift
//  Notes
//
//  Created by bmiit on 21/03/22.
//

import UIKit

class NotedetailsVC: UIViewController
{

    @IBOutlet var titleTF: UITextField!
    
    @IBOutlet var descTV: UITextView!
    override func viewDidLoad()
    {
        super.viewDidLoad()
       
    }

    @IBAction func saveAction(_ sender: Any) {
    }
    
}

