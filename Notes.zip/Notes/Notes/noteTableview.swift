import UIKit

class notTableview:UITableViewController
{
    
}
