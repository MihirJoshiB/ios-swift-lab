import UIKit
import CoreData
var noteList = [Note]()
var selectedNote: Note? = nil

class noteTableview:UITableViewController
{
    var firstload = true
    
    func nonDeletedNotes() -> [Note]
    {
        var noDeletedNoteList = [Note]()
        for note in noteList
        {
            if(note.deletedDate == nil)
            {
                noDeletedNoteList.append(note)
            }
        }
        
        return noDeletedNoteList
    }
    
    override func viewDidLoad()
    {
        if(firstload)
        {
            firstload = false
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context: NSManagedObjectContext = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
            
            do {
                let results:NSArray = try context.fetch(request) as NSArray
                for result in results
                {
                    let note = result as! Note
                    noteList.append(note)
                }
            }
            catch
            {
                print("Fetch Failed")
            }
        }
        

    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let noteCell = tableView.dequeueReusableCell(withIdentifier: "notecell",for: indexPath) as! notecell
        
        let thisnote: Note!
        thisnote = nonDeletedNotes()[indexPath.row]
        noteCell.titleLabel.text = thisnote.title
        noteCell.descLabel.text = thisnote.desc
        return noteCell
       
    }
   
    
    @IBAction func DEE(_ sender: UIButton)
    {
        let ip = tableView.indexPathForSelectedRow
        let thisnote: Note?
        thisnote = nonDeletedNotes()[ip!.row]
        //let notecelll = tableView.dequeueReusableCell(withIdentifier: "notecell")
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context: NSManagedObjectContext = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
        
       
        do {
            let results:NSArray = try context.fetch(request) as NSArray
            for result in results
            {
                let note = result as! Note
                if(note == selectedNote)
                {
                    note.deletedDate = Date()
                    try context.save()
                    navigationController?.popViewController(animated: true)
                }
            }
        }
        catch
        {
            print("Fetch Failed")
        }
        


        
        //tableView.reloadData()
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return nonDeletedNotes().count
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        self.performSegue(withIdentifier: "editNote", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "editNote")
        {
            let indexPath = tableView.indexPathForSelectedRow!
            
            let noteDetail = segue.destination as? NotedetailsVC
            
            let selectedNote : Note!
            selectedNote =  nonDeletedNotes()[indexPath.row]
            noteDetail!.selectedNote = selectedNote
            
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }
}
