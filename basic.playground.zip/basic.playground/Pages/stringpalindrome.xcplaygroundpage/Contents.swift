//: [Previous](@previous)

import Foundation

var st : String
var re : String

st = "mihir"
re = String(st.reversed())

print("orginal string : \(st)")
print("reverse string : \(re)")

