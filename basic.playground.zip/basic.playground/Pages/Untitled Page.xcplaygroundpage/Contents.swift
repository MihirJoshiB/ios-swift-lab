import UIKit

func check_prime(num: Int) -> Int
{
    var c = 0
    var i = 1
    while(i <= num)
    {
        if(num % i == 0)
        {
            c = c + 1
        }
        i = i + 1
    }
    return c
}

var count = check_prime(num: 6)
if(count == 2)
{
    print("Prime")
}
else
{
    print("Not Prime")
}
