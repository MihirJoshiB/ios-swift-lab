import UIKit
func check_palindrome(num: Int) -> Int
{
    var reverse = 0
    var remainder = 0
    var n = num
    
    while(n != 0)
    {
        remainder = n % 10
        reverse = reverse * 10 + remainder
        n = n / 10
    }
    if(reverse == num)
    {
        return 1
    }
    else
    {
        return 0
    }
}

var c = check_palindrome(num: 161)
if(c == 1)
{
    print("Palindrome")
}
else
{
    print("Not Palindrome")
}
