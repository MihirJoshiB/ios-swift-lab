import UIKit

import Foundation
func check_armstrong(num: Int)
{
    var n = num
    var count = 0
    
    while(n != 0)
    {
        n = n / 10
        count+=1
    }
    var temp = num
    var digit = 0
    var sum = 0
    while(temp > 0)
    {
        digit = temp % 10
        sum = sum + (digit * digit * digit)
        temp /= 10
    }
    if(num == sum)
    {
        print("Armstrong")
    }
    else
    {
        print("Not Armstrong")
    }
    return
}
check_armstrong(num: 153)
